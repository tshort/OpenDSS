function [methodinfo,structs,enuminfo,ThunkLibName]=DEngineProto
%OpenDSSDEngineProto Create structures to define interfaces found in 'OpenDSSDEngine.dll'.

ival={cell(1,0)}; % change 0 to the actual number of functions to preallocate the data.
structs=[];enuminfo=[];fcnNum=1;
fcns=struct('name',ival,'calltype',ival,'LHS',ival,'RHS',ival,'alias',ival);
ThunkLibName=[];
%  int32_t DSSI(int32_t Parameter, int32_t Argument); 
fcns.name{fcnNum}='DSSI'; fcns.calltype{fcnNum}='cdecl'; fcns.LHS{fcnNum}='int32'; fcns.RHS{fcnNum}={'int32', 'int32'};fcnNum=fcnNum+1;
%  int32_t DSSLoads(int32_t Parameter, int32_t argument); 
fcns.name{fcnNum}='DSSLoads'; fcns.calltype{fcnNum}='cdecl'; fcns.LHS{fcnNum}='int32'; fcns.RHS{fcnNum}={'int32', 'int32'};fcnNum=fcnNum+1;
%  double DSSLoadsF(int32_t Parameter, double Argument); 
fcns.name{fcnNum}='DSSLoadsF'; fcns.calltype{fcnNum}='cdecl'; fcns.LHS{fcnNum}='double'; fcns.RHS{fcnNum}={'int32', 'double'};fcnNum=fcnNum+1;
%  CStr DSSPut_Command(CStr Command); 
fcns.name{fcnNum}='DSSPut_Command'; fcns.calltype{fcnNum}='cdecl'; fcns.LHS{fcnNum}='cstring'; fcns.RHS{fcnNum}={'cstring'};fcnNum=fcnNum+1;
structs.c_struct.members=struct('p1', 'double', 'p2', 'int16', 'p3', 'long');
%enuminfo.Enum1=struct('en1',1,'en2',2,'en4',4);
methodinfo=fcns;