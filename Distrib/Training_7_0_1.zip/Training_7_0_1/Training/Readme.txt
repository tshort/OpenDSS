Level1.pdf and Level2.pdf contain the PowerPoint slides from two
single-day OpenDSS training sessions conducted by EPRI in April 2009.
These were presented to 2 different audiences, and there is some
overlap between the slide decks.

The slides reference version 6.3.1 of OpenDSS, including examples
and scripts in the release download for version 6.3.1.