clear;
clc;

%*****Parameter definition****
Start = 3; %starts OpenDSS
First = 0; %Loads First
Next = 1;  %Loads Next
kW = 1;    %Loads kW write
kvar = 5;  %Loads kvar write
Count = 4; %Loads Count

% Connect to the DLL
%addpath(fullfile(pwd))

loadlibrary('OpenDSSDirect.dll',@DEngineProto);
libfunctions('OpenDSSDirect')
calllib('OpenDSSDirect','DSSI',Start,0);
calllib('OpenDSSDirect','DSSPut_Command','clear');
calllib('OpenDSSDirect','DSSPut_Command','compile (C:\Users\pdmo005\Documents\OpenDSS\8500-Node\master.dss)');
t=cputime;
for i=1:1000
    Lnumber=calllib('OpenDSSDirect','DSSLoads',First,0);
    while Lnumber > 0
        calllib('OpenDSSDirect','DSSLoadsF',kW,50);
        calllib('OpenDSSDirect','DSSLoadsF',kvar,20);
        Lnumber=calllib('OpenDSSDirect','DSSLoads',Next,0);
    end
end
total=cputime-t;
formatSpec = 'It takes %d seconds %d loads 1000 times';
TotalL=calllib('OpenDSSDirect','DSSLoads',Count,0);
sprintf(formatSpec,total,TotalL)
% Disconenct the DLL
unloadlibrary 'OpenDSSDirect'

